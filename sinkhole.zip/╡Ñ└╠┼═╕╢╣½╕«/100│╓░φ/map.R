library(dplyr)
library(readxl)
library('ggmap')

data <- read_excel("광주75퍼이상12곳.xls")
register_google(key='AIzaSyBqN81KrgtVTbQ0kDvMCfvREjtmL9rV1eo')

df<-tbl_df(data)



cen <- c(126.8740	,35.16160)
map <- get_googlemap(center = cen,
                     maptype="roadmap",
                     zoom=12,
                     size=c(640,640))#,marker=df)
ggmap(map) 



ggmap(map) + geom_point(data=df, aes(x=lon, y=lat, color="blue")) 
