library(readxl)
data <- read_excel("fake.xls")

fit <- lm(발생~., data=data)

summary(fit)
