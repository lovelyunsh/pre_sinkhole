library(dplyr)
library(readxl)
library('ggmap')

data <- read_excel("광주.xls")
register_google(key='AIzaSyBqN81KrgtVTbQ0kDvMCfvREjtmL9rV1eo')

gc <- geocode(enc2utf8(data$지역명))
table(is.na(gc))
write.csv(gc,"광주latlon.csv")
