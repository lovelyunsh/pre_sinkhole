library(readxl)
data <- read_excel("국내지진목록_20140101_20190805 (1).xls")
install.packages("ggmap")
library('ggmap')
register_google(key='AIzaSyBqN81KrgtVTbQ0kDvMCfvREjtmL9rV1eo')
names <- data$지반침하지역상세 
addr <- data$지반침하지역상세
gc <- geocode(enc2utf8(addr))

gc

df <- data.frame(
  lon=data$경도,
  lat=data$위도)
df
cen <- c(126.9219750,37.575330)
cen
map <- get_googlemap(center = cen,
                     maptype="roadmap",
                     zoom=10,
                     size=c(640,640),
                     marker=gc)
ggmap(map) 
