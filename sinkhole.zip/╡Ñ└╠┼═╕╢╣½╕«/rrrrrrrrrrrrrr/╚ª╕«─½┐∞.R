data = read_excel("반대.xls")
gc3 <- tbl_df(data)

library(dplyr)
library()
tb
library("ggmap")
register_google(key='AIzaSyBqN81KrgtVTbQ0kDvMCfvREjtmL9rV1eo')
addr <- data$
gc <- geocode(enc2utf8(addr))
View(gc)

table(is.na(gc))

gc2$lon <- data$lon


