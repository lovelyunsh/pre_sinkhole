library(readxl)
data <- read_excel("no.xls")
View(data)
fit <- lm(싱크홀발생여부~.,data=data)
summary(fit)

