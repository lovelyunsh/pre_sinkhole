library(readxl)
pL <- read_excel("원본에다가랑게리아.xls")

pop <- pL$인구밀도
Li <- pL$랑게리아지수
pipe <- pL$노후관비율


cor(pipe,pop)
cor(pipe,Li)

cor(pL$랑게리아지수,pL$노후관비율)

library(ggplot2)


