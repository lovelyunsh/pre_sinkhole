pop <- read.csv("2019pop.csv")
summary(pop)

