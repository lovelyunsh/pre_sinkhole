install.packages("readxl")
library(readxl)
data <- read_excel("전국지반침하정보표준데이터(원본).xls")
install.packages("ggmap")
library('ggmap')
register_google(key='AIzaSyBqN81KrgtVTbQ0kDvMCfvREjtmL9rV1eo')
names <- data$지반침하지역상세 
addr <- data$지반침하지역상세
gc <- geocode(enc2utf8(addr))

class(gc)
gc
df <- data.frame(
                 lon=data$경도,
                 lat=data$위도)
df
cen <- c(126.9219750,36.675330)
cen
map <- get_googlemap(center = cen,
                     maptype="hybrid",
                     zoom=7,
                     size=c(640,640),
                     marker=gc3)
ggmap(map) 
