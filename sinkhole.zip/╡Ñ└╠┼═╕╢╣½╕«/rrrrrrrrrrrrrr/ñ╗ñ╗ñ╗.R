library(readxl)
data <- read.csv("하이잉.csv")
data
library('ggmap')
register_google(key='AIzaSyBqN81KrgtVTbQ0kDvMCfvREjtmL9rV1eo')


names <- data$
addr <- data$지반침하지역상세
df

gc

df <- data.frame(
  lon=data$경도,
  lat=data$위도)
df
cen <- c(126.9219750,37.575330)
cen
map <- get_googlemap(center = cen,
                     maptype="roadmap",
                     zoom=10,
                     size=c(640,640),
                     marker=df)
ggmap(map) 
